# Projeto Integrado - Plataforma Grupou
## Atividade da semana 01

Para visualizar apenas os diagramas, acesse a pasta diagramas_exportados.

Para melhor contexto, comece pelo arquivo relatorio.pdf.

Este trabalho também pode ser encontrado no [Github](https://github.com/lgcavalheiro/dev-mobile-class-repo/tree/master/grupou-atividade-semana-1 "Github") .

---

<img src="natural-results.png" alt="NLU Results" width="960"/>
